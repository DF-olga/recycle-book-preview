/* =====================================================================
   回收圖鑑 ReMap 互動增補（示範用）2026-10-05
   ・本檔只用於視覺提案預覽：以 DOM 增補方式示範三項改動，正式版請作者在 React 原始碼實作（規格見改動說明第八節）
   1. 稱號：只顯示目前等級徽章，點徽章開啟所有稱號與目標
   2. 法源：把代碼（例：表一-電子電器-電視機）轉成白話說明
   3. 品項面板：新增「找最近回收點」按鈕
   ===================================================================== */
(function(){
  /* --- 稱號規則（2026-10-05 開發作者提供）---
     等級稱號：累計解鎖 5／25／50 項、全部集滿（總數由資料 grand_total 帶入，不寫死）
     類別稱號（8 個）：某一類全部集滿即獲得；名稱待作者提供，預覽以「○○類全部集滿」示意 */
  const SHOW_CAT_TITLES=false;  /* 類別稱號（8 個）名稱尚未提供，暫不顯示；有資料後改為 true */
  const TITLES=[{name:'回收見習生',need:5},{name:'分類研究員',need:25},{name:'循環行動家',need:50},{name:'零廢棄大師',need:'all'}];
  /* 等級頭像（2026-10-05）：正式素材到位後，把 AVATAR_IMG 填入圖檔路徑（例：assets/title-lv1.webp），即改用 3D 頭像；
     目前以簡單圖形示意：表情符號風格的黃色圓臉，每級換一個表情＋一件配件（害羞微笑＋見習帽 → 專注＋眼鏡 → 握拳咧嘴＋頭帶 → 星星眼＋皇冠） */
  const AVATAR_IMG=['assets/title-lv1.webp','assets/title-lv2.webp','assets/title-lv3.webp','assets/title-lv4.webp'];  /* 設計者提供的 3D 表情圓臉頭像；AVATAR_SVG 僅作圖檔讀取失敗時的備用 */
  const AVATAR_SVG=["<svg viewBox=\"0 0 100 100\" aria-hidden=\"true\"><circle cx=\"50\" cy=\"50\" r=\"48\" fill=\"#E3F4FA\"/><circle cx=\"50\" cy=\"54\" r=\"34\" fill=\"#FFC83D\"/><circle cx=\"50\" cy=\"54\" r=\"34\" fill=\"none\" stroke=\"#E3A008\" stroke-width=\"1.5\"/><ellipse cx=\"38\" cy=\"36\" rx=\"10\" ry=\"5\" fill=\"#fff\" opacity=\".45\" transform=\"rotate(-25 38 36)\"/><ellipse cx=\"40\" cy=\"52\" rx=\"4\" ry=\"5.5\" fill=\"#3A2A12\"/><ellipse cx=\"60\" cy=\"52\" rx=\"4\" ry=\"5.5\" fill=\"#3A2A12\"/><path d=\"M42 66q8 6 16 0\" stroke=\"#3A2A12\" stroke-width=\"3\" fill=\"none\" stroke-linecap=\"round\"/><ellipse cx=\"31\" cy=\"62\" rx=\"5\" ry=\"3\" fill=\"#FF9AA2\" opacity=\".7\"/><ellipse cx=\"69\" cy=\"62\" rx=\"5\" ry=\"3\" fill=\"#FF9AA2\" opacity=\".7\"/><path d=\"M24 34q26-26 52 0z\" fill=\"#2B8FD8\"/><path d=\"M22 33h56a3 3 0 0 1 0 6H22a3 3 0 0 1 0-6z\" fill=\"#1B6FB0\"/><circle cx=\"50\" cy=\"14\" r=\"4\" fill=\"#1B6FB0\"/></svg>", "<svg viewBox=\"0 0 100 100\" aria-hidden=\"true\"><circle cx=\"50\" cy=\"50\" r=\"48\" fill=\"#E3F4FA\"/><circle cx=\"50\" cy=\"54\" r=\"34\" fill=\"#FFC83D\"/><circle cx=\"50\" cy=\"54\" r=\"34\" fill=\"none\" stroke=\"#E3A008\" stroke-width=\"1.5\"/><ellipse cx=\"38\" cy=\"36\" rx=\"10\" ry=\"5\" fill=\"#fff\" opacity=\".45\" transform=\"rotate(-25 38 36)\"/><circle cx=\"39\" cy=\"52\" r=\"9\" fill=\"#fff\" opacity=\".35\" stroke=\"#3E484C\" stroke-width=\"3\"/><circle cx=\"61\" cy=\"52\" r=\"9\" fill=\"#fff\" opacity=\".35\" stroke=\"#3E484C\" stroke-width=\"3\"/><path d=\"M48 52h4\" stroke=\"#3E484C\" stroke-width=\"3\"/><circle cx=\"39\" cy=\"53\" r=\"3.5\" fill=\"#3A2A12\"/><circle cx=\"61\" cy=\"53\" r=\"3.5\" fill=\"#3A2A12\"/><path d=\"M44 68q6 3 12 0\" stroke=\"#3A2A12\" stroke-width=\"3\" fill=\"none\" stroke-linecap=\"round\"/><path d=\"M31 39q8-5 15-1M56 36q8-6 15 0\" stroke=\"#3A2A12\" stroke-width=\"2.5\" fill=\"none\" stroke-linecap=\"round\"/></svg>", "<svg viewBox=\"0 0 100 100\" aria-hidden=\"true\"><circle cx=\"50\" cy=\"50\" r=\"48\" fill=\"#E3F4FA\"/><circle cx=\"50\" cy=\"54\" r=\"34\" fill=\"#FFC83D\"/><circle cx=\"50\" cy=\"54\" r=\"34\" fill=\"none\" stroke=\"#E3A008\" stroke-width=\"1.5\"/><ellipse cx=\"38\" cy=\"36\" rx=\"10\" ry=\"5\" fill=\"#fff\" opacity=\".45\" transform=\"rotate(-25 38 36)\"/><path d=\"M20 40q30-10 60 0v8q-30-10-60 0z\" fill=\"#E94B3C\"/><path d=\"M80 42l10-6-2 10z\" fill=\"#E94B3C\"/><path d=\"M33 50l10 3M67 50l-10 3\" stroke=\"#3A2A12\" stroke-width=\"3\" stroke-linecap=\"round\"/><ellipse cx=\"40\" cy=\"58\" rx=\"3.5\" ry=\"4.5\" fill=\"#3A2A12\"/><ellipse cx=\"60\" cy=\"58\" rx=\"3.5\" ry=\"4.5\" fill=\"#3A2A12\"/><path d=\"M38 66q12 12 24 0z\" fill=\"#3A2A12\"/><path d=\"M41 67h18v3H41z\" fill=\"#fff\"/><path d=\"M76 54q4 7 0 9q-4-2 0-9z\" fill=\"#7FD8F0\"/></svg>", "<svg viewBox=\"0 0 100 100\" aria-hidden=\"true\"><circle cx=\"50\" cy=\"50\" r=\"48\" fill=\"#E3F4FA\"/><circle cx=\"50\" cy=\"54\" r=\"34\" fill=\"#FFC83D\"/><circle cx=\"50\" cy=\"54\" r=\"34\" fill=\"none\" stroke=\"#E3A008\" stroke-width=\"1.5\"/><ellipse cx=\"38\" cy=\"36\" rx=\"10\" ry=\"5\" fill=\"#fff\" opacity=\".45\" transform=\"rotate(-25 38 36)\"/><polygon points=\"39.0,46.0 40.9,50.5 45.7,50.8 42.0,54.0 43.1,58.7 39.0,56.1 34.9,58.7 36.0,54.0 32.3,50.8 37.1,50.5\" fill=\"#E94B3C\"/><polygon points=\"61.0,46.0 62.9,50.5 67.7,50.8 64.0,54.0 65.1,58.7 61.0,56.1 56.9,58.7 58.0,54.0 54.3,50.8 59.1,50.5\" fill=\"#E94B3C\"/><path d=\"M38 64q12 14 24 0z\" fill=\"#3A2A12\"/><path d=\"M42 70q8 5 16 0\" fill=\"#FF7A85\"/><path d=\"M30 26l7 9 13-16 13 16 7-9v14H30z\" fill=\"#F4C430\" stroke=\"#C98A00\" stroke-width=\"1.2\"/><circle cx=\"50\" cy=\"22\" r=\"2.5\" fill=\"#E94B3C\"/><path d=\"M14 25l1.5 3.5 3.5 1.5-3.5 1.5-1.5 3.5-1.5-3.5-3.5-1.5 3.5-1.5z\" fill=\"#FFD84D\"/><path d=\"M86 23l1.5 3.5 3.5 1.5-3.5 1.5-1.5 3.5-1.5-3.5-3.5-1.5 3.5-1.5z\" fill=\"#FFD84D\"/><path d=\"M88 57l1.5 3.5 3.5 1.5-3.5 1.5-1.5 3.5-1.5-3.5-3.5-1.5 3.5-1.5z\" fill=\"#FFD84D\"/><path d=\"M12 61l1.5 3.5 3.5 1.5-3.5 1.5-1.5 3.5-1.5-3.5-3.5-1.5 3.5-1.5z\" fill=\"#FFD84D\"/></svg>"];
  const avatar=(i,cls)=>{ const lock=/tav-lock/.test(cls||''); const svg=lock?AVATAR_SVG[i].replace(/<circle cx="50" cy="50" r="48"[^>]*\/>/,''):AVATAR_SVG[i]; return `<span class="tav ${cls||''}">${AVATAR_IMG[i]?`<img src="${AVATAR_IMG[i]}" alt="" decoding="async" onerror="this.replaceWith(document.createRange().createContextualFragment(${JSON.stringify(svg).replace(/"/g,'&quot;')}))">`:svg}</span>`; };
  const nums=()=>{ const n=document.querySelector('.summary__number'); const total=parseInt(n?.firstChild?.textContent||'0',10)||0; const all=parseInt(n?.querySelector('small')?.textContent||'0',10)||0; return {total,all}; };
  const needOf=t=>t.need==='all'?nums().all:t.need;
  const levelIndex=()=>{ const {total}=nums(); let k=-1; TITLES.forEach((t,i)=>{ const n=needOf(t); if(n&&total>=n) k=i; }); return k; };

  /* --- 法源白話轉換 ---
     五條六＝廢棄物清理法第5條第6項公告「執行機關一般廢棄物應回收項目」（清潔隊回收項目）
     表一／表二＝廢棄物清理法第15條第2項「公告應回收廢棄物」：表一為物品類、表二為容器類（依資料歸納，請作者與機關確認） */
  const LAW_515='廢棄物清理法第5條第6項', LAW_152='廢棄物清理法第15條第2項';
  /* 法源代碼 → 白話對照表（A＝清潔隊資源回收項目、B＝公告應回收物品、C＝公告應回收容器），涵蓋示範資料全部 43 種寫法 */
  const LEGAL_MAP={"五條六-三-光碟片": ["A", "光碟片"], "五條六-二(一)-紙類": ["A", "紙類"], "五條六-二(一)-紙類（概括項）": ["A", "紙類"], "五條六-二(二)(三)-鐵類／鋁類（概括項）": ["A", "鐵類、鋁類"], "五條六-二(五)-塑膠類": ["A", "塑膠類"], "五條六-二(五)-塑膠類-PVC": ["A", "塑膠類（PVC）"], "五條六-二(四)-玻璃類": ["A", "玻璃類"], "五條六-五-食用油": ["A", "廢食用油"], "五條六-四-行動電話": ["A", "行動電話"], "五條六-四-行動電話充電器": ["A", "行動電話充電器"], "表一-乾電池": ["B", "乾電池"], "表一-平板包材-免洗餐具": ["B", "免洗餐具（平板包裝材料）"], "表一-平板包材-塑膠平板包材": ["B", "塑膠平板包裝材料"], "表一-平板包材-塑膠平板包材/泡殼": ["B", "塑膠平板包裝材料（泡殼）"], "表一-平板包材-紙平板容器": ["B", "紙製平板容器"], "表一-機動車輛": ["B", "機動車輛"], "表一-照明光源": ["B", "照明光源"], "表一-資訊物品(廣義)": ["B", "資訊物品"], "表一-資訊物品-主機板/硬碟/電源器": ["B", "資訊物品（主機板、硬碟、電源器）"], "表一-資訊物品-印表機": ["B", "資訊物品（印表機）"], "表一-資訊物品-可攜式電腦": ["B", "資訊物品（可攜式電腦）"], "表一-資訊物品-機殼": ["B", "資訊物品（機殼）"], "表一-資訊物品-鍵盤": ["B", "資訊物品（鍵盤）"], "表一-資訊物品-顯示器": ["B", "資訊物品（顯示器）"], "表一-輪胎": ["B", "輪胎"], "表一-鉛蓄電池": ["B", "鉛蓄電池"], "表一-電子電器-冷暖氣機": ["B", "電子電器（冷暖氣機）"], "表一-電子電器-洗衣機": ["B", "電子電器（洗衣機）"], "表一-電子電器-電冰箱": ["B", "電子電器（電冰箱）"], "表一-電子電器-電視機": ["B", "電子電器（電視機）"], "表一-電子電器-電風扇": ["B", "電子電器（電風扇）"], "表一-非平板類免洗餐具": ["B", "免洗餐具（非平板類）"], "表二-容器(環境用藥)": ["C", "環境用藥容器"], "表二-容器-塑膠": ["C", "塑膠容器"], "表二-容器-塑膠(環境用藥)": ["C", "塑膠容器（環境用藥）"], "表二-容器-塑膠(藥品)": ["C", "塑膠容器（藥品）"], "表二-容器-塑膠(農藥)": ["C", "塑膠容器（農藥）"], "表二-容器-玻璃": ["C", "玻璃容器"], "表二-容器-鋁/鐵": ["C", "鐵鋁容器"], "表二-容器-鐵": ["C", "鐵容器"], "表二-容器附件(蓋/拉環)": ["C", "容器附件（瓶蓋、拉環）"], "表二-容器-PS發泡": ["C", "發泡塑膠（PS）容器"], "表二-容器-紙": ["C", "紙容器"]};
  const KIND={A:['屬於清潔隊資源回收項目',LAW_515],B:['屬於環境部公告應回收物品',LAW_152],C:['屬於環境部公告應回收容器',LAW_152]};
  function plainOne(code){
    code=code.trim(); const hit=LEGAL_MAP[code]; if(hit){ const k=KIND[hit[0]]; return {text:`${k[0]}：${hit[1]}`,law:k[1]}; }
    if(/^五條六/.test(code)) return {text:'屬於清潔隊資源回收項目',law:LAW_515};
    if(/^表一/.test(code)) return {text:'屬於環境部公告應回收物品',law:LAW_152};
    if(/^表二/.test(code)) return {text:'屬於環境部公告應回收容器',law:LAW_152};
    return {text:code,law:''};
  }
  function plainLegal(raw){ const list=raw.split(/[;；]/).map(plainOne); const laws=[...new Set(list.map(x=>x.law).filter(Boolean))];
    return {lines:list.map(x=>x.text), law:laws.length?('依據：'+laws.join('、')):''}; }
  window.__plainLegal=plainLegal;

  /* --- 共用：底部說明面板 --- */
  function openInfo(){
    const {total}=nums(), cur=levelIndex();
    const rows=TITLES.map((t,i)=>{ const need=needOf(t), isCur=i===cur, done=i<cur;
      const st=isCur?'<span class="lvl-st cur">目前等級</span>':done?'<span class="lvl-st done">已達成</span>':`<span class="lvl-st todo">再蒐集 ${Math.max(need-total,0)} 項</span>`;
      const cond=t.need==='all'?`${need} 項全部集滿`:`累計解鎖 ${need} 項`;
      return `<li class="lvl-row${isCur?' is-cur':''}${!done&&!isCur?' is-lock':''}">${avatar(i,!done&&!isCur?'tav-lock':'')}<span class="lvl-main"><span class="lvl-no">Lv.${i+1}</span><b>${t.name}</b><small>${cond}</small></span>${st}</li>`; }).join('');
    const cats=[...document.querySelectorAll('.band')].map(b=>{ const name=(b.querySelector('.band__title')||{}).textContent||''; const m=((b.querySelector('.band__count')||{}).textContent||'').match(/(\d+)\D+(\d+)/); return m?{name,c:+m[1],t:+m[2]}:null; }).filter(Boolean);
    const catRows=cats.map(x=>{ const got=x.c>=x.t; return `<li class="cat-row${got?' is-got':''}"><span class="cat-main"><b>${x.name}</b><small>${x.name}全部集滿</small></span><span class="cat-prog" aria-label="已蒐集 ${x.c}，共 ${x.t}">${x.c} / ${x.t}</span>${got?'<span class="lvl-st done">已獲得</span>':`<span class="lvl-st todo">再蒐集 ${x.t-x.c} 項</span>`}</li>`; }).join('');
    const gotCats=cats.filter(x=>x.c>=x.t).length;
    const wrap=document.createElement('div'); wrap.className='lvl-ov';
    wrap.innerHTML=`<div class="lvl-bg" data-x></div><section class="lvl-panel" role="dialog" aria-modal="true" aria-labelledby="lvl-t"><button class="lvl-x" type="button" aria-label="關閉" data-x>✕</button><h2 id="lvl-t">回收稱號</h2><p class="lvl-d">每解鎖一項回收物，就離下一個稱號更近一步。</p>
      ${SHOW_CAT_TITLES?'<h3 class="lvl-h">等級稱號</h3>':''}<ol class="lvl-list">${rows}</ol>
      ${SHOW_CAT_TITLES?`<h3 class="lvl-h">類別稱號 <span>${gotCats} / ${cats.length}</span></h3><p class="lvl-d2">把某一類全部集滿，就能獲得該類的專屬稱號。</p><ul class="lvl-list cat-list">${catRows}</ul>`:''}
      <p class="lvl-note">示例資料</p></section>`;
    document.body.appendChild(wrap);
    const btn=document.querySelector('.lv-badge'); const close=()=>{wrap.remove();btn&&btn.focus();};
    wrap.addEventListener('click',e=>{ if(e.target.closest('[data-x]')) close(); });
    wrap.addEventListener('keydown',e=>{ if(e.key==='Escape') close(); });
    wrap.querySelector('.lvl-x').focus();
  }


  /* ===== 吸睛優化（2026-10-05，設計者指示 #1 #2；#6 NEW 標籤已依指示移除） ===== */
  const MAX_VISIBLE=9;  /* #1 收合規則：每類最多先顯示 3 行（9 格）；超過 9 項時顯示前 8 項，第 9 格改為「+N」；已蒐集的品項一律顯示不收合 */
  function enhanceGrid(){
    document.querySelectorAll('.cat .grid').forEach(grid=>{
      if(grid.dataset.rmFold) return; grid.dataset.rmFold='1';
      const all=[...grid.querySelectorAll(':scope > .slot')];
      const got=all.filter(li=>!li.classList.contains('slot--locked')).length;
      const extra=all.length>MAX_VISIBLE?all.slice(Math.max(MAX_VISIBLE-1,got)):[];
      if(extra.length){
        extra.forEach(li=>li.classList.add('rm-hide'));
        const li=document.createElement('li'); li.className='slot rm-more-slot';
        li.innerHTML=`<button type="button" class="rm-more" aria-expanded="false"><span class="rm-more-n">+${extra.length}</span><span class="rm-more-t">還有 ${extra.length} 個<br>等你發現</span></button>`;
        grid.appendChild(li);
        li.querySelector('button').addEventListener('click',()=>{ extra.forEach(x=>x.classList.remove('rm-hide')); li.remove(); (extra[0]?.querySelector('button')||grid).focus?.(); });
      }
    });
  }
  /* #2 首屏下一步目標 */
  function enhanceNext(){
    const bar=document.querySelector('.summary__bar'); if(!bar||document.querySelector('.rm-next')) return;
    const {total}=nums(), k=levelIndex(), nx=TITLES[k+1];
    const el=document.createElement('p'); el.className='rm-next';
    if(nx){ const need=needOf(nx); el.innerHTML=`${avatar(k+1,'tav-lock tav-mini')}<span>再解鎖 <b>${Math.max(need-total,0)}</b> 項，升級 <b>Lv.${k+2} ${nx.name}</b></span>`; }
    else el.innerHTML=`${avatar(TITLES.length-1,'tav-mini')}<span>已達最高等級，太厲害了！</span>`;
    bar.after(el);
  }
  function enhance(){
    /* 1. 稱號：只顯示目前等級 */
    const ul=document.querySelector('.summary__titles');
    if(ul&&!ul.dataset.lv){
      const k=levelIndex(); const name=k>=0?TITLES[k].name:'尚未獲得稱號'; const lvNo=k+1;  /* 依稱號規則：累計解鎖數達到的最高等級 */
      ul.dataset.lv='1'; ul.hidden=true;
      const lv=document.createElement('div'); lv.className='lv';
      lv.innerHTML=`<button type="button" class="lv-badge has-av" aria-haspopup="dialog" aria-label="${lvNo?`目前等級 Lv.${lvNo} ${name}`:name}，點一下查看所有回收稱號與目標">${k>=0?avatar(k,'tav-badge'):''}<span class="lv-txt">${lvNo?`<span class="lv-no">Lv.${lvNo}</span>`:''}<b>${name}</b></span><span class="lv-more" aria-hidden="true"></span></button>`;
      ul.after(lv); lv.querySelector('.lv-badge').addEventListener('click',openInfo);  /* 點稱號徽章直接開啟稱號面板（取消「!」按鈕） */
    }
    /* 2、3. 品項面板 */
    const panel=document.querySelector('.sheet-panel');
    if(panel&&!panel.dataset.rm){
      panel.dataset.rm='1';
      [...panel.querySelectorAll('div')].forEach(d=>{ if(/法源\s*$/.test(d.textContent.trim())&&d.nextElementSibling&&d.nextElementSibling.tagName==='P'){
        const p=d.nextElementSibling, r=plainLegal(p.textContent);
        d.lastChild.textContent='法規依據';
        p.innerHTML=r.lines.map(t=>`<span class="law-line">${t}</span>`).join('')+(r.law?`<span class="law-src">${r.law}</span>`:''); p.classList.add('law-plain'); } });
      const cta=[...panel.querySelectorAll('button,a')].find(b=>/回對話再拍一張/.test(b.textContent));
      if(cta){ const name=(panel.querySelector('h2')||{}).textContent||'';
        const row=document.createElement('div'); row.className='sheet-cta-row'; cta.parentNode.insertBefore(row,cta);
        const map=document.createElement('button'); map.type='button'; map.className='sheet-map';
        map.innerHTML='<span class="ic" aria-hidden="true"></span>找最近回收點';
        map.addEventListener('click',()=>{ const t=document.createElement('div'); t.className='rm-toast'; t.setAttribute('role','status'); t.textContent=`示例：正式版會帶著「${name}」開啟回收地圖`; document.body.appendChild(t); setTimeout(()=>t.remove(),2600); });
        row.appendChild(map); row.appendChild(cta); }
    }
  }
  const _enh=enhance; enhance=function(){ _enh(); enhanceGrid(); enhanceNext(); };
  new MutationObserver(()=>enhance()).observe(document.documentElement,{childList:true,subtree:true});
  document.addEventListener('DOMContentLoaded',()=>enhance()); enhance();
})();
